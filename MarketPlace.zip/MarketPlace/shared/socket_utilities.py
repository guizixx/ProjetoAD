# Grupo: 47
# Guilherme Pinto - nº 60260 
# Tiago Telha - nº 60261
# Descrição: classes utilitárias ao uso de sockets

import ipaddress

from shared.excepcoes_shared import ExcepcaoIPInvalido
from shared.excepcoes_shared import ExcepcaoPortoInvalido
from shared.excepcoes_shared import ExcecaoLigacaoInterrompida

class PontoAcesso:
    def __init__(self, endereco_ip, porto):
        # Validar IP e porto
        # Lança ExcepcaoIPInvalido e ExcepcaoPortoInvalido
        self._validar_endereco_ip(endereco_ip)
        self._validar_porto(porto)

        self.endereco_ip = endereco_ip
        self.porto = porto

    def _validar_porto(self, porto):
        try:
            porto = int(porto)
        except (ValueError, TypeError):
            raise ExcepcaoPortoInvalido(porto)

        if not (1024 <= porto <= 65535):
            raise ExcepcaoPortoInvalido(porto)

    def _validar_endereco_ip(self, endereco_ip):
        # Validar IP (IPv4 ou IPv6)
        try:
            if 'localhost' != endereco_ip:
                ipaddress.ip_address(endereco_ip)
        except ValueError as e:
            raise ExcepcaoIPInvalido(endereco_ip)
        
        
def receive_all(socket, length):
    try:
        resposta = b""
        while len(resposta) < length:
            parte = socket.recv(length-len(resposta))
            resposta += parte
            if resposta.endswith(b"\n"):
                break
        return resposta
    except ExcecaoLigacaoInterrompida as e:
        raise e